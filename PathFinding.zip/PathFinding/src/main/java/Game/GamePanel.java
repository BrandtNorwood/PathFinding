/*
 * To change this license header, choose License Headers in Project Properties
 * To change this template file, choose Tools | Templates
 * and open the template in the editor
 */
package Game;

import Controller.KeyboardController;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;
import GameObjects.*;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;

/**
 *
 * @author 
 */
public class GamePanel extends JPanel
{
    // These are for handling the frame rate of the game and player controls
    // You should pass the controller to any objects you create that will
    //  be under keyboard control
    private Timer gameTimer; 
    private KeyboardController controller = new KeyboardController(); 
    
    // Controls size of game window and framerate
    // You can adjust these if you want to use different values 
    private final int gameWidth = 600;  
    private final int gameHeight = 720; 
    private final int framesPerSecond = 60;
    
    int score = 0;
    int livesRemaining = 3;
    boolean showHitBoxes = false;
    boolean gameWon = false;
    boolean gameLost= false;
    boolean isDead = false;
    boolean startMenu = true;
    boolean reachedDestination = false;
    int currentX = 15,currentY = 1;
    int pathFoundAt = 0;
    boolean fullPathFound = false;
    
    Ship ship = new Ship(300,680,Color.RED, controller);
    
    Rectangle gameBounds = new Rectangle(0,0,600,720);
    Font font = new Font("Monospaced",2,15);
    ArrayList<Sheild> sheildList = new ArrayList<>();
    Node[][] nodeList = new Node[30][36];
        
    /**
     * This method is called by the GameFrame class when starting the game for 
     *  the first time. It should be used like a constructor method where you
     *  initialize all of the instance variables. 
     * You can also use this method to reset a game after a player wins or loses
     *  and wants to play again. 
     */
    public final void setupGame()
    {
        reachedDestination = false;
        currentX = 15; currentY = 1;
        sheildList.clear();
        
        ship.setXPosition(310); ship.setYPosition(670);
        
        Random random = new Random();
        
        for (int i = 0; i<40; i++){
            Sheild newSheild = new Sheild(random.nextInt(600),random.nextInt(500)+50, random.nextInt(50)+20, random.nextInt(50)+20, Color.cyan);
            sheildList.add(newSheild);
        }
        
        for(int y = 0; y<720; y= y+20){
                for(int x = 0; x<600; x=x+20){
                Node newSheild = new Node(x,y,20,20,Color.BLACK);
                nodeList[x/20][y/20] = newSheild;
            }
        }
        
        for(Sheild thisSheild : sheildList){
            for(int y = 0; y<720; y= y+20){
                for(int x = 0; x<600; x=x+20){
                    if(nodeList[x/20][y/20].getBounds().intersects(thisSheild.getBounds())){
                        nodeList[x/20][y/20].setFilled(true);
                        nodeList[x/20][y/20].setColor(Color.RED);
                    }
                }
            }
        }
        
        for(int y = 0; y<720; y= y+20){
            for(int x = 0; x<600; x=x+20){
                if(nodeList[x/20][y/20].getBounds().intersects(ship.getBounds())) nodeList[x/20][y/20].setScanned(true);
            }
        }
        
        nodeList[15][1].setVictory(true);
        nodeList[15][1].setColor(Color.LIGHT_GRAY);
        
    }
    
    /**
     * This method is automatically called by the game timer every frame. As typical,
     *  you should use it to draw all of your game objects.
     * 
     * @param g The Graphics object used for drawing the GameObject instances.
     */
    @Override
    public void paint(Graphics g)
    {
        //Draw Background
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 600, 720);
       
        if (true){ //use this to disable the node map
            for(int y = 0; y<720; y= y+20){
                for(int x = 0; x<600; x=x+20){
                    nodeList[x/20][y/20].draw(g);
                    g.setColor(Color.BLACK);
                    if (nodeList[x/20][y/20].getScanned() || nodeList[x/20][y/20].getNewScan()){
                        g.drawString(Integer.toString(nodeList[x/20][y/20].getScore()), x+4, y+15);
                    }
                }
            }
        }
        
        for(int y = 0; y<720; y= y+20){g.drawLine(0, y, 600, y);}
         
        for(int x = 0; x<600; x=x+20){g.drawLine(x, 0, x, 720);}
        
        //Draw Ship
        ship.draw(g);
        if (showHitBoxes){
            g.setColor(Color.red);
            g.drawRect(ship.getBounds().x, ship.getBounds().y, ship.getBounds().width, ship.getBounds().height);
        }
        
        
        
        //Draw Sheilds
        for (Sheild thisSheild : sheildList){
            thisSheild.draw(g);
            if (showHitBoxes){
                g.setColor(Color.red);
                g.drawRect(thisSheild.getBounds().x, thisSheild.getBounds().y, thisSheild.getBounds().width, thisSheild.getBounds().height);
            }
        }
    }
    
    /**
     * This method is automatically called by the game timer every frame. Any of your
     *  code for moving game objects or handling collisions, etc. should be done 
     *  by this method. 
     * The method has a single parameter which represents the 
     *  current frame number, which is incremented by the Timer each time before 
     *  the method is called. You can assume that it will always increase, but it
     *  will eventually overflow if the game runs long enough (something like 1 year)
     * 
     * @param frameNumber The number of the current frame.
     */
   
    
    
    public void updateGameState(int frameNumber){
        
        if (!reachedDestination){
            
            for(int y = 0; y<36; y++){
                for(int x = 0; x<30; x++){
                    if (nodeList[x][y].getNewScan()){
                        nodeList[x][y].setNewScan(false);
                        nodeList[x][y].setScanned(true);
                    }
                }
            }
            
            for(int y = 0; y<36; y++){
                for(int x = 0; x<30; x++){
                    if (nodeList[x][y].getScanned()){
                        if (x+1<30){ if(!(nodeList[x+1][y].getFilled()|| nodeList[x+1][y].getScanned())){ nodeList[x+1][y].setNewScan(true);}}
                        if (x-1>=0){ if(!(nodeList[x-1][y].getFilled()|| nodeList[x-1][y].getScanned())){nodeList[x-1][y].setNewScan(true);}}
                        if (y+1<36){ if(!(nodeList[x][y+1].getFilled()|| nodeList[x][y+1].getScanned())){nodeList[x][y+1].setNewScan(true);}}
                        if (y-1>=0){ if(!(nodeList[x][y-1].getFilled()|| nodeList[x][y-1].getScanned())){nodeList[x][y-1].setNewScan(true);}}
                    }
                }
            }
            
            for(int y = 0; y<36; y++){
                for(int x = 0; x<30; x++){
                   if(nodeList[x][y].getScanned() || nodeList[x][y].getNewScan()) nodeList[x][y].setScore(nodeList[x][y].getScore()+1);
                }
            }
            
            for(int y = 0; y<36; y++){
                for(int x = 0; x<30; x++){
                    if(nodeList[x][y].getNewScan() && nodeList[x][y].getVictory()) reachedDestination = true;
                }
            }
        }
        
        if (reachedDestination){
            nodeList[15][33].setScore(50);
            //if bottom is lowest compared to other 3 mark as path found and set as current point

                fullPathFound = false;
                if (!fullPathFound){
                try{
                    if (   nodeList[currentX][currentY+1].getScore()>=nodeList[currentX][currentY-1].getScore()
                        && nodeList[currentX][currentY+1].getScore()>=nodeList[currentX+1][currentY].getScore()
                        && nodeList[currentX][currentY+1].getScore()>=nodeList[currentX-1][currentY].getScore()){
                        currentY++; nodeList[currentX][currentY].setVictory(true);}

                    else if (   nodeList[currentX][currentY-1].getScore()>=nodeList[currentX][currentY+1].getScore()
                        && nodeList[currentX][currentY-1].getScore()>=nodeList[currentX+1][currentY].getScore()
                        && nodeList[currentX][currentY-1].getScore()>=nodeList[currentX-1][currentY].getScore()){
                        currentY--; nodeList[currentX][currentY].setVictory(true);}

                    else if (   nodeList[currentX-1][currentY].getScore()>=nodeList[currentX+1][currentY].getScore()
                        && nodeList[currentX-1][currentY].getScore()>=nodeList[currentX][currentY+1].getScore()
                        && nodeList[currentX-1][currentY].getScore()>=nodeList[currentX][currentY-1].getScore()){
                        currentX--; nodeList[currentX][currentY].setVictory(true);}

                    else if (   nodeList[currentX+1][currentY].getScore()>=nodeList[currentX-1][currentY].getScore()
                        && nodeList[currentX+1][currentY].getScore()>=nodeList[currentX][currentY+1].getScore()
                        && nodeList[currentX+1][currentY].getScore()>=nodeList[currentX][currentY-1].getScore()){
                        currentX++; nodeList[currentX][currentY].setVictory(true);}

                }catch (IndexOutOfBoundsException e){System.err.println("Cum");}
                
                if(currentX==15 && currentY == 33){ fullPathFound = true; pathFoundAt = frameNumber;}
            }
        }
        
        if (controller.getSpaceKeyStatus())this.setupGame();
        
        if (false){
        
            if (controller.getRightKeyStatus() && ship.getXPosition()<590){
                ship.setXPosition(ship.getXPosition()+5);
                
                Boolean sheildCollision = false;
                for (Sheild thisSheild : sheildList){
                    if (ship.getBounds().intersects(thisSheild.getBounds())){
                        sheildCollision = true;
                    }
                }
                
                if (sheildCollision) ship.setXPosition(ship.getXPosition()-5);
            }
            
            
            if (controller.getUpKeyStatus() && ship.getYPosition()>10){
                ship.setYPosition(ship.getYPosition()-5);
                
                Boolean sheildCollision = false;
                for (Sheild thisSheild : sheildList){
                    if (ship.getBounds().intersects(thisSheild.getBounds())){
                        sheildCollision = true;
                    }
                }
                
                if (sheildCollision) ship.setYPosition(ship.getYPosition()+5);
            }
            
            
            if (controller.getDownKeyStatus() && ship.getYPosition()<710){
                ship.setYPosition(ship.getYPosition()+5);
                
                Boolean sheildCollision = false;
                for (Sheild thisSheild : sheildList){
                    if (ship.getBounds().intersects(thisSheild.getBounds())){
                        sheildCollision = true;
                    }
                }
                
                if (sheildCollision) ship.setYPosition(ship.getYPosition()-5);
            }
        }
    }
    
   
    /**
     * Constructor method for GamePanel class.
     * It is not necessary for you to modify this code at all
     */
    public GamePanel()
    {
        // Set the size of the Panel
        this.setSize(gameWidth, gameHeight);
        this.setPreferredSize(new Dimension(gameWidth, gameHeight));
        
        this.setBackground(Color.BLACK);
        
        // Register KeyboardController as KeyListener
        controller = new KeyboardController(); 
        this.addKeyListener(controller); 
        
        // Call setupGame to initialize fields
        this.setupGame(); 
        
        this.setFocusable(true);
        this.requestFocusInWindow();
    }
    
    /**
     * Method to start the Timer that drives the animation for the game.
     * It is not necessary for you to modify this code unless you need to in 
     *  order to add some functionality. 
     */
    public void start()
    {
        // Set up a new Timer to repeat based on the set framesPerSecond
        gameTimer = new Timer(1000 / framesPerSecond, new ActionListener() {

            // Tracks the number of frames that have been produced.
            // May be useful for limiting action rates
            private int frameNumber = 0; 
                        
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                // Update the game's state and repaint the screen
                updateGameState(frameNumber++);
                repaint();  
            }
        });
        
        gameTimer.setRepeats(true);
        gameTimer.start();
    }
}
