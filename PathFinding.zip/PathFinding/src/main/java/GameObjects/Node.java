/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author Brandt(School)
 */
public class Node extends GameObject{
    private int width, height;
    private int score;
    private boolean filled;
    private boolean scanned,newScan ,victory;

    public Node(int xPosition, int yPosition, int width, int height, Color color) {
        super(xPosition, yPosition, color);
        this.width = width;
        this.height = height;
        this.score = 0;
        this.filled = false;
        this.scanned = false;
        this.newScan = false;
        this.victory = false;
        
    }
    
    public int getWidth(){return width;}
    public int getHeight(){return height;}
    
    public int getScore(){return score;}
    public boolean getFilled(){return filled;}
    public boolean getScanned(){return scanned;}
    public boolean getNewScan(){return newScan;}
    public boolean getVictory(){return victory;}
    
    public void setWidth(int width){this.width = width;}
    public void setHeight(int height){this.height = height;}
    
    public void setScore(int score){this.score = score;}
    public void setFilled(boolean filled){this.filled = filled;}
    public void setScanned(boolean scanned){this.scanned = scanned;}
    public void setNewScan(boolean scanned){this.newScan = scanned;}
    public void setVictory(boolean victory){this.victory = victory;}
    
    public void setColor(Color color){this.color = color;}
    
    public void draw(Graphics g){
        g.setColor(color);
        if (filled || victory || scanned || newScan){
            if (filled) g.setColor(Color.RED);
            if (newScan) g.setColor(Color.YELLOW);
            if (scanned) g.setColor(new Color(0,255-(score*4),score*4));
            if (victory) g.setColor(Color.magenta);
            g.fillRect(xPosition, yPosition, width, height);
        }
        else g.drawRect(xPosition, yPosition, width, height);
    }
    
    @Override
    public Rectangle getBounds(){
        return new Rectangle(xPosition, yPosition, width, height);
    }
}
