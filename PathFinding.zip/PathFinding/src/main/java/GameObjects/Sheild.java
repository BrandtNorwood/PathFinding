/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author Brandt(School)
 */
public class Sheild extends GameObject{
    private int width, height;

    public Sheild(int xPosition, int yPosition, int width, int height, Color color) {
        super(xPosition, yPosition, color);
        this.width = width;
        this.height = height;
    }
    
    public int getWidth(){return width;}
    public int getHeight(){return height;}
    
    public void setWidth(int width){this.width = width;}
    public void setHeight(int height){this.height = height;}
    
    @Override
    public void draw(Graphics g){
        g.setColor(color);
        g.fillRect(xPosition, yPosition, width, height);
    }
    
    public void drawOutline(Graphics g){
        g.setColor(color);
        g.drawRect(xPosition, yPosition, width, height);
    }
    
    @Override
    public Rectangle getBounds(){
        return new Rectangle(xPosition, yPosition, width, height);
    }
    
}
