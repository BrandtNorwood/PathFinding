/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GameObjects;

import java.awt.Color;
import java.awt.Rectangle;

/**
 *
 * @author Brandt(School)
 */
public abstract class GameObject implements Interfaces.Drawable {
    
    protected int xPosition, yPosition;
    protected Color color;
    
    public GameObject(int xPosition, int yPosition, Color color){
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
    }
    
    public abstract Rectangle getBounds();

    public int getXPosition(){return xPosition;}
    public int getYPosition(){return yPosition;}
    public Color getColor(){return color;}
    
    public void setXPosition(int xPosition){this.xPosition = xPosition;}
    public void setYPosition(int yPosition){this.yPosition = yPosition;}
    public void setColor(Color color){this.color = color;}
    
    //collision detection using rectangles as hit boxes
    public boolean isColliding(GameObject other){
        Rectangle thisRectangle = this.getBounds();
        Rectangle otherRectangle = other.getBounds();
        
        return thisRectangle.intersects(otherRectangle);
    }
    
}
