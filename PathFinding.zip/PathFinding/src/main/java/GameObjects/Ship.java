/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GameObjects;

import Controller.KeyboardController;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author Brandt(School)
 */
public class Ship extends ControlledGameObject{
    private int scale = 4;//Easy way to scale the ship!
    private Color shipColor = Color.blue;
    
    public Ship(int xPosition, int yPosition, Color color, KeyboardController controller){
        super(xPosition, yPosition, color, controller);
    }
    
    public void setScale(int scale){this.scale = scale;}
    public void setShipColor(Color color){this.shipColor = color;}
    
    @Override
    public Rectangle getBounds(){
        return new Rectangle(xPosition-10, yPosition-10, 20, 20);
    }
    
    @Override
    public void move(){
        if (controller.getLeftKeyStatus()){xPosition -= 10;} 
        if (controller.getRightKeyStatus()){xPosition += 10;}
        if (controller.getUpKeyStatus()){yPosition += 10;}
        if (controller.getDownKeyStatus()){yPosition -= 10;}
    }
    
    @Override
    public void draw(Graphics g){
        g.setColor(shipColor);
        //draw in the ship!
        g.fillRect(xPosition-10, yPosition-10, 20, 20);
        
       
    }
}
